from setuptools import setup
setup(name="aviconfigreader",
version=0.1,
description="package is used to read config/yaml files",
author="Avinash",
packages=["aviconfigreader"])