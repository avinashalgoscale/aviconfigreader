import os

def readconfig(input_file, output_file):
    return output_file