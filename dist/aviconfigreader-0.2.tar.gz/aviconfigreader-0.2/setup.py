from setuptools import setup


setup(name="aviconfigreader",
version=0.2,
description="package is used to read config/yaml files",
author="Avinash",
packages=["aviconfigreader"],
install_requires=["wheel", "pyyaml", "configparser"])